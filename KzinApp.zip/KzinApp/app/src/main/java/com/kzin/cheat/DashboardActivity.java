package com.kzin.cheat;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.TextView;

public class DashboardActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String userKey = getIntent().getStringExtra("USER_KEY");
        String hwid = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);

        TextView tvUserKey = (TextView) findViewById(R.id.tvUserKey);
        TextView tvHwid = (TextView) findViewById(R.id.tvHwid);

        tvUserKey.setText("User: " + userKey);
        tvHwid.setText("HWID: " + hwid);
    }
}