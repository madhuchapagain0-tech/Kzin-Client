package com.kzin.client;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

public class LoginActivity extends Activity {
    
    EditText keyInput;
    Button loginBtn;
    Button tgBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        keyInput = (EditText) findViewById(R.id.keyInput);
        loginBtn = (Button) findViewById(R.id.loginBtn);
        tgBtn = (Button) findViewById(R.id.tgBtn);

        tgBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/Kzin_Madhu"));
                startActivity(browserIntent);
            }
        });

        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String key = keyInput.getText().toString().trim();
                if (key.isEmpty()) {
                    Toast.makeText(LoginActivity.this, "Enter a license key", Toast.LENGTH_SHORT).show();
                } else {
                    loginBtn.setText("Authenticating...");
                    loginBtn.setEnabled(false);
                    verifyKey(key);
                }
            }
        });
    }

    private void verifyKey(final String key) {
        final String hwid = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    URL url = new URL("https://kzin-cheats.de2.netrun.io/api/verify");
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("POST");
                    conn.setRequestProperty("Content-Type", "application/json");
                    conn.setDoOutput(true);

                    String jsonInputString = "{\"key\": \"" + key + "\", \"hwid\": \"" + hwid + "\"}";

                    try (OutputStream os = conn.getOutputStream()) {
                        byte[] input = jsonInputString.getBytes("utf-8");
                        os.write(input, 0, input.length);
                    }

                    Scanner scanner = new Scanner(conn.getInputStream());
                    StringBuilder response = new StringBuilder();
                    while (scanner.hasNext()) response.append(scanner.nextLine());
                    scanner.close();

                    final String resStr = response.toString();

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (resStr.contains("\"status\": \"success\"") || resStr.contains("\"status\":\"success\"")) {
                                Toast.makeText(LoginActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(LoginActivity.this, DashboardActivity.class);
                                intent.putExtra("USER_KEY", key);
                                startActivity(intent);
                                finish();
                            } else {
                                Toast.makeText(LoginActivity.this, "Invalid Key or HWID Mismatch", Toast.LENGTH_LONG).show();
                                loginBtn.setText("AUTHENTICATE");
                                loginBtn.setEnabled(true);
                            }
                        }
                    });
                } catch (Exception e) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(LoginActivity.this, "Network Error", Toast.LENGTH_LONG).show();
                            loginBtn.setText("AUTHENTICATE");
                            loginBtn.setEnabled(true);
                        }
                    });
                }
            }
        }).start();
    }
}