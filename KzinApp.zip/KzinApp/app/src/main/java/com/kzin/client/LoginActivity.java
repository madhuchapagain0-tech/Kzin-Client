package com.kzin.client;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

public class LoginActivity extends Activity {
    EditText keyInput;
    RelativeLayout loginBtnLayout;
    TextView loginBtnText;
    ProgressBar loginProgress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        keyInput = findViewById(R.id.keyInput);
        loginBtnLayout = findViewById(R.id.loginBtnLayout);
        loginBtnText = findViewById(R.id.loginBtnText);
        loginProgress = findViewById(R.id.loginProgress);

        SharedPreferences prefs = getSharedPreferences("KzinPrefs", Context.MODE_PRIVATE);
        String savedKey = prefs.getString("license_key", "");
        if (!savedKey.isEmpty()) keyInput.setText(savedKey);

        findViewById(R.id.tgBtn).setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/Kzin_Madhu"))));

        loginBtnLayout.setOnClickListener(v -> {
            String key = keyInput.getText().toString().trim();
            if (key.isEmpty()) {
                Toast.makeText(LoginActivity.this, "Enter a license key", Toast.LENGTH_SHORT).show();
            } else {
                setLoading(true);
                verifyKey(key);
            }
        });
    }

    private void setLoading(boolean isLoading) {
        if (isLoading) {
            loginBtnText.setVisibility(View.GONE);
            loginProgress.setVisibility(View.VISIBLE);
            loginBtnLayout.setEnabled(false);
        } else {
            loginBtnText.setVisibility(View.VISIBLE);
            loginProgress.setVisibility(View.GONE);
            loginBtnLayout.setEnabled(true);
        }
    }

    private void verifyKey(final String key) {
        final String hwid = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        new Thread(() -> {
            try {
                URL url = new URL("https://kzin-cheats.de2.netrun.io/api/verify");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setDoOutput(true);

                String jsonInputString = "{\"key\": \"" + key + "\", \"hwid\": \"" + hwid + "\"}";
                try (OutputStream os = conn.getOutputStream()) {
                    byte[] input = jsonInputString.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                Scanner scanner = new Scanner(conn.getInputStream());
                StringBuilder response = new StringBuilder();
                while (scanner.hasNext()) response.append(scanner.nextLine());
                scanner.close();
                final String resStr = response.toString();

                runOnUiThread(() -> {
                    if (resStr.contains("\"status\": \"success\"") || resStr.contains("\"status\":\"success\"")) {
                        Toast.makeText(LoginActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                        getSharedPreferences("KzinPrefs", Context.MODE_PRIVATE).edit().putString("license_key", key).apply();
                        Intent intent = new Intent(LoginActivity.this, DashboardActivity.class);
                        intent.putExtra("USER_KEY", key);
                        startActivity(intent);
                        finish();
                    } else {
                        Toast.makeText(LoginActivity.this, "Invalid Key", Toast.LENGTH_LONG).show();
                        setLoading(false);
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    Toast.makeText(LoginActivity.this, "Network Error", Toast.LENGTH_LONG).show();
                    setLoading(false);
                });
            }
        }).start();
    }
}