package com.kzin.client;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

public class LoginActivity extends Activity {
    EditText keyInput;
    RelativeLayout loginBtnLayout;
    TextView loginBtnText;
    ProgressBar loginProgress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        keyInput = findViewById(R.id.keyInput);
        loginBtnLayout = findViewById(R.id.loginBtnLayout);
        loginBtnText = findViewById(R.id.loginBtnText);
        loginProgress = findViewById(R.id.loginProgress);

        SharedPreferences prefs = getSharedPreferences("KzinPrefs", Context.MODE_PRIVATE);
        String savedKey = prefs.getString("license_key", "");
        if (!savedKey.isEmpty()) keyInput.setText(savedKey);

        findViewById(R.id.tgBtn).setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/Kzin_Madhu"))));

        loginBtnLayout.setOnClickListener(v -> {
            String key = keyInput.getText().toString().trim();
            if (key.isEmpty()) {
                Toast.makeText(LoginActivity.this, "Enter a license key", Toast.LENGTH_SHORT).show();
            } else {
                setLoading(true);
                verifyKey(key);
            }
        });
    }

    private void setLoading(boolean isLoading) {
        if (isLoading) {
            loginBtnText.setVisibility(View.GONE);
            loginProgress.setVisibility(View.VISIBLE);
            loginBtnLayout.setEnabled(false);
        } else {
            loginBtnText.setVisibility(View.VISIBLE);
            loginProgress.setVisibility(View.GONE);
            loginBtnLayout.setEnabled(true);
        }
    }

    private void verifyKey(final String key) {
        final String hwid = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        new Thread(() -> {
            try {
                URL url = new URL("https://kzin-cheats.de2.netrun.io/api/verify");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setDoOutput(true);

                String jsonInputString = "{\"key\": \"" + key + "\", \"hwid\": \"" + hwid + "\"}";
                try (OutputStream os = conn.getOutputStream()) {
                    byte[] input = jsonInputString.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                // Fix for reading error streams (4xx/5xx responses)
                InputStream is = (conn.getResponseCode() >= 400) ? conn.getErrorStream() : conn.getInputStream();
                Scanner scanner = new Scanner(is);
                StringBuilder response = new StringBuilder();
                while (scanner.hasNext()) response.append(scanner.nextLine());
                scanner.close();
                final String resStr = response.toString();

                runOnUiThread(() -> {
                    setLoading(false);
                    try {
                        JSONObject json = new JSONObject(resStr);
                        String status = json.optString("status");
                        
                        if (status.equalsIgnoreCase("success")) {
                            Toast.makeText(LoginActivity.this, "Login Success!", Toast.LENGTH_SHORT).show();
                            
                            // Save Key locally
                            getSharedPreferences("KzinPrefs", Context.MODE_PRIVATE).edit().putString("license_key", key).apply();
                            
                            // Extract data from JSON (fallbacks provided if backend doesn't send them yet)
                            String expiry = json.optString("expiry", "N/A");
                            
                            // Navigate to Dashboard and pass the data
                            Intent intent = new Intent(LoginActivity.this, DashboardActivity.class);
                            intent.putExtra("USER_KEY", key);
                            intent.putExtra("HWID", hwid);
                            intent.putExtra("EXPIRY", expiry);
                            startActivity(intent);
                            finish();
                            
                        } else {
                            String msg = json.optString("message", "Invalid or Expired Key");
                            Toast.makeText(LoginActivity.this, msg, Toast.LENGTH_LONG).show();
                        }
                    } catch (Exception e) {
                        Toast.makeText(LoginActivity.this, "Server Error. Try again.", Toast.LENGTH_SHORT).show();
                    }
                });

            } catch (Exception e) {
                runOnUiThread(() -> {
                    setLoading(false);
                    Toast.makeText(LoginActivity.this, "Network Error", Toast.LENGTH_SHORT).show();
                });
            }
        }).start();
    }
}