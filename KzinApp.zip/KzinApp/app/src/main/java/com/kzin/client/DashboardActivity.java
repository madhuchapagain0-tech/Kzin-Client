package com.kzin.client;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.TextView;

public class DashboardActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // Reusing the old layout for now

        String userKey = getIntent().getStringExtra("USER_KEY");
        String hwid = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);

        TextView tvUserKey = findViewById(R.id.tvUserKey);
        TextView tvHwid = findViewById(R.id.tvHwid);
        TextView tvAndroid = findViewById(R.id.tvAndroid);
        TextView tvModel = findViewById(R.id.tvModel);
        TextView tvBrand = findViewById(R.id.tvBrand);

        tvUserKey.setText("User: " + userKey);
        tvHwid.setText("HWID: " + hwid);
        tvAndroid.setText("Android: " + Build.VERSION.RELEASE);
        tvModel.setText("Model: " + Build.MODEL);
        tvBrand.setText("Brand: " + Build.BRAND);
    }
}