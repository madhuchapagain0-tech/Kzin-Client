package com.kzin.client;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.AssetManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.Locale;
import java.util.UUID;

public class DashboardActivity extends Activity {

    LinearLayout pageGames, pageProfile, pageSettings;
    TextView navGames, navProfile, navSettings;
    TextView tvRootStatus, tvSyscallStatus;

    private Handler handler = new Handler(Looper.getMainLooper());
    private Runnable statusUpdater;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        pageGames = findViewById(R.id.pageGames);
        pageProfile = findViewById(R.id.pageProfile);
        pageSettings = findViewById(R.id.pageSettings);
        navGames = findViewById(R.id.navGames);
        navProfile = findViewById(R.id.navProfile);
        navSettings = findViewById(R.id.navSettings);
        
        tvRootStatus = findViewById(R.id.tvRootStatus);
        tvSyscallStatus = findViewById(R.id.tvSyscallStatus);

        navGames.setOnClickListener(v -> switchTab(0));
        navProfile.setOnClickListener(v -> switchTab(1));
        navSettings.setOnClickListener(v -> switchTab(2));

        loadProfileData();

        statusUpdater = new Runnable() {
            @Override
            public void run() {
                loadSettingsData();
                handler.postDelayed(this, 2000);
            }
        };

        findViewById(R.id.btnLaunchMLBB).setOnClickListener(v -> {
            Toast.makeText(this, "Injecting Stealth Root...", Toast.LENGTH_SHORT).show();
            executeMLBBScript();
        });
        
        findViewById(R.id.btnViewLog).setOnClickListener(v -> showTerminalLog());
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(statusUpdater);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(statusUpdater);
    }

    private void switchTab(int tabIndex) {
        pageGames.setVisibility(tabIndex == 0 ? View.VISIBLE : View.GONE);
        pageProfile.setVisibility(tabIndex == 1 ? View.VISIBLE : View.GONE);
        pageSettings.setVisibility(tabIndex == 2 ? View.VISIBLE : View.GONE);

        if (tabIndex == 0) pageGames.startAnimation(AnimationUtils.loadAnimation(this, R.anim.slide_up));
        if (tabIndex == 1) pageProfile.startAnimation(AnimationUtils.loadAnimation(this, R.anim.slide_up));
        if (tabIndex == 2) pageSettings.startAnimation(AnimationUtils.loadAnimation(this, R.anim.slide_up));

        navGames.setTextColor(getColor(tabIndex == 0 ? R.color.cyan : R.color.text_grey));
        navProfile.setTextColor(getColor(tabIndex == 1 ? R.color.cyan : R.color.text_grey));
        navSettings.setTextColor(getColor(tabIndex == 2 ? R.color.cyan : R.color.text_grey));
    }

    private void loadProfileData() {
        Intent intent = getIntent();
        String userKey = intent.getStringExtra("USER_KEY");
        String expiry = intent.getStringExtra("EXPIRY");
        String hwid = intent.getStringExtra("HWID");

        if (userKey == null) userKey = "KZIN-UNKNOWN";
        if (expiry == null) expiry = "Lifetime";
        if (hwid == null) hwid = android.provider.Settings.Secure.getString(getContentResolver(), android.provider.Settings.Secure.ANDROID_ID);

        TextView tvUserKey = findViewById(R.id.tvUserKey);
        TextView tvExpiry = findViewById(R.id.tvExpiry);
        TextView tvHwid = findViewById(R.id.tvHwid);
        
        tvUserKey.setText(userKey);
        tvExpiry.setText(expiry);
        tvHwid.setText(hwid);

        String finalHwid = hwid;
        ImageView btnCopyHwid = findViewById(R.id.btnCopyHwid);
        btnCopyHwid.setOnClickListener(v -> {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData clip = ClipData.newPlainText("HWID", finalHwid);
            clipboard.setPrimaryClip(clip);
            Toast.makeText(this, "HWID Copied!", Toast.LENGTH_SHORT).show();
        });

        TextView tvAndroid = findViewById(R.id.tvAndroid);
        TextView tvModel = findViewById(R.id.tvModel);
        TextView tvBrand = findViewById(R.id.tvBrand);
        TextView tvAbi = findViewById(R.id.tvAbi);
        TextView tvKernel = findViewById(R.id.tvKernel);
        TextView tvDisplay = findViewById(R.id.tvDisplay);

        tvAndroid.setText("Android " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")");
        tvModel.setText(Build.MODEL);
        tvBrand.setText(Build.BRAND);
        tvAbi.setText(Build.SUPPORTED_ABIS[0]);
        tvKernel.setText(System.getProperty("os.version"));

        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        float refreshRate = getWindowManager().getDefaultDisplay().getRefreshRate();
        tvDisplay.setText(String.format(Locale.US, "%.0fhz, %dx%d", refreshRate, metrics.widthPixels, metrics.heightPixels));
    }

    private void loadSettingsData() {
        if (isDeviceRooted()) {
            tvRootStatus.setText("DETECTED");
            tvRootStatus.setTextColor(getColor(R.color.success));
            tvRootStatus.setBackgroundResource(R.drawable.badge_active);
        } else {
            tvRootStatus.setText("NOT ROOTED");
            tvRootStatus.setTextColor(getColor(R.color.danger));
            tvRootStatus.setBackgroundResource(R.drawable.badge_inactive);
        }

        if (checkSyscalls()) {
            tvSyscallStatus.setText("ACTIVE");
            tvSyscallStatus.setTextColor(getColor(R.color.success));
            tvSyscallStatus.setBackgroundResource(R.drawable.badge_active);
        } else {
            tvSyscallStatus.setText("INACTIVE");
            tvSyscallStatus.setTextColor(getColor(R.color.danger));
            tvSyscallStatus.setBackgroundResource(R.drawable.badge_inactive);
        }
    }

    private boolean isDeviceRooted() {
        try {
            Process process = Runtime.getRuntime().exec("su -c id");
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line = reader.readLine();
            return line != null && line.contains("uid=0");
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkSyscalls() {
        try {
            Process process = Runtime.getRuntime().exec("su -c ps -A");
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                String lower = line.toLowerCase();
                // Checks for our hidden process name
                if (lower.contains(".sys_logger") || lower.contains("mlbb.sh")) {
                    return true;
                }
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    private void executeMLBBScript() {
        new Thread(() -> {
            try {
                // 1. GENERATE RANDOM STEALTH PATH
                String randomId = UUID.randomUUID().toString().substring(0, 8);
                String stealthPath = "/data/local/tmp/." + randomId;
                
                File internalDir = new File(getFilesDir(), randomId);
                if (!internalDir.exists()) internalDir.mkdirs();

                // 2. Extract ONLY mlbb.sh (Faster)
                AssetManager am = getAssets();
                InputStream is = am.open("mlbb.sh");
                File outFile = new File(internalDir, "mlbb.sh");
                OutputStream os = new FileOutputStream(outFile);
                byte[] buffer = new byte[1024];
                int length;
                while ((length = is.read(buffer)) > 0) {
                    os.write(buffer, 0, length);
                }
                os.flush();
                os.close();
                is.close();

                // 3. Copy to hidden path and execute with Normal Root (Input 1)
                String command = "su -mm -c \"cp -r " + internalDir.getAbsolutePath() + " " + stealthPath + " && " +
                                 "cd " + stealthPath + " && " +
                                 "chmod -R 777 * && " +
                                 "export PATH=$PATH:/system/bin:/system/xbin:/sbin && " +
                                 "export TERM=xterm-256color && " +
                                 "printf '1\\n' | exec -a .sys_logger setsid sh mlbb.sh > debug.log 2>&1 & " +
                                 "sleep 2 && rm -rf " + internalDir.getAbsolutePath() + " &\"";

                ProcessBuilder pb = new ProcessBuilder("su", "-c", command);
                pb.redirectErrorStream(true);
                pb.start();

                runOnUiThread(() -> {
                    Toast.makeText(this, "Injected! Open Game.", Toast.LENGTH_LONG).show();
                    switchTab(2); 
                });

            } catch (Exception e) {
                runOnUiThread(() -> {
                    Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }
    
    private void showTerminalLog() {
        File tmpDir = new File("/data/local/tmp");
        File[] dirs = tmpDir.listFiles((dir, name) -> name.startsWith(".") && name.length() == 9); 
        
        if (dirs == null || dirs.length == 0) {
            Toast.makeText(this, "No active script found.", Toast.LENGTH_SHORT).show();
            return;
        }
        
        File latestDir = dirs[0];
        for (File f : dirs) {
            if (f.lastModified() > latestDir.lastModified()) latestDir = f;
        }
        
        File logFile = new File(latestDir, "debug.log");
        if (!logFile.exists()) {
            Toast.makeText(this, "Log file not found.", Toast.LENGTH_SHORT).show();
            return;
        }
        
        try {
            Process p = Runtime.getRuntime().exec("su -c cat " + logFile.getAbsolutePath());
            BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append("\n");
            }
            reader.close();
            
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Terminal Output");
            builder.setMessage(sb.toString());
            builder.setPositiveButton("CLOSE", null);
            builder.show();
            
        } catch (Exception e) {
            Toast.makeText(this, "Failed to read log.", Toast.LENGTH_SHORT).show();
        }
    }
}