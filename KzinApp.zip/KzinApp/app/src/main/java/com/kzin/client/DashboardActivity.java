package com.kzin.client;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.Locale;

public class DashboardActivity extends Activity {

    LinearLayout pageGames, pageProfile, pageSettings;
    TextView navGames, navProfile, navSettings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize Navigation
        pageGames = findViewById(R.id.pageGames);
        pageProfile = findViewById(R.id.pageProfile);
        pageSettings = findViewById(R.id.pageSettings);
        navGames = findViewById(R.id.navGames);
        navProfile = findViewById(R.id.navProfile);
        navSettings = findViewById(R.id.navSettings);

        // Navigation Click Listeners
        navGames.setOnClickListener(v -> switchTab(0));
        navProfile.setOnClickListener(v -> switchTab(1));
        navSettings.setOnClickListener(v -> switchTab(2));

        // Load Data
        loadProfileData();
        loadSettingsData();

        // Launch Game Logic
        findViewById(R.id.btnLaunchMLBB).setOnClickListener(v -> {
            Toast.makeText(this, "Injecting MLBB Kernel Script...", Toast.LENGTH_SHORT).show();
            // Add your actual launch logic here (e.g., accessing assets/mlbb.sh)
        });
    }

    private void switchTab(int tabIndex) {
        pageGames.setVisibility(tabIndex == 0 ? View.VISIBLE : View.GONE);
        pageProfile.setVisibility(tabIndex == 1 ? View.VISIBLE : View.GONE);
        pageSettings.setVisibility(tabIndex == 2 ? View.VISIBLE : View.GONE);

        navGames.setTextColor(getColor(tabIndex == 0 ? R.color.cyan : R.color.text_grey));
        navProfile.setTextColor(getColor(tabIndex == 1 ? R.color.cyan : R.color.text_grey));
        navSettings.setTextColor(getColor(tabIndex == 2 ? R.color.cyan : R.color.text_grey));
    }

    private void loadProfileData() {
        // Retrieve data passed from LoginActivity
        Intent intent = getIntent();
        String userKey = intent.getStringExtra("USER_KEY");
        String expiry = intent.getStringExtra("EXPIRY");
        String hwid = intent.getStringExtra("HWID");

        if (userKey == null) userKey = "KZIN-UNKNOWN";
        if (expiry == null) expiry = "N/A";
        if (hwid == null) hwid = android.provider.Settings.Secure.getString(getContentResolver(), android.provider.Settings.Secure.ANDROID_ID);

        TextView tvUserKey = findViewById(R.id.tvUserKey);
        TextView tvExpiry = findViewById(R.id.tvExpiry);
        TextView tvHwid = findViewById(R.id.tvHwid);
        
        tvUserKey.setText(userKey);
        tvExpiry.setText(expiry);
        tvHwid.setText(hwid);

        // Copy HWID Logic
        String finalHwid = hwid;
        ImageView btnCopyHwid = findViewById(R.id.btnCopyHwid);
        btnCopyHwid.setOnClickListener(v -> {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData clip = ClipData.newPlainText("HWID", finalHwid);
            clipboard.setPrimaryClip(clip);
            Toast.makeText(this, "HWID Copied!", Toast.LENGTH_SHORT).show();
        });

        // Device Specs
        TextView tvAndroid = findViewById(R.id.tvAndroid);
        TextView tvModel = findViewById(R.id.tvModel);
        TextView tvBrand = findViewById(R.id.tvBrand);
        TextView tvAbi = findViewById(R.id.tvAbi);
        TextView tvKernel = findViewById(R.id.tvKernel);
        TextView tvDisplay = findViewById(R.id.tvDisplay);

        tvAndroid.setText("Android " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")");
        tvModel.setText(Build.MODEL);
        tvBrand.setText(Build.BRAND);
        tvAbi.setText(Build.SUPPORTED_ABIS[0]);
        tvKernel.setText(System.getProperty("os.version"));

        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        float refreshRate = getWindowManager().getDefaultDisplay().getRefreshRate();
        tvDisplay.setText(String.format(Locale.US, "%.0fhz, %dx%d", refreshRate, metrics.widthPixels, metrics.heightPixels));
    }

    private void loadSettingsData() {
        TextView tvRootStatus = findViewById(R.id.tvRootStatus);
        TextView tvSyscallStatus = findViewById(R.id.tvSyscallStatus);

        if (isDeviceRooted()) {
            tvRootStatus.setText("DETECTED");
            tvRootStatus.setTextColor(getColor(android.R.color.holo_green_light));
        } else {
            tvRootStatus.setText("NOT ROOTED");
            tvRootStatus.setTextColor(getColor(android.R.color.holo_red_light));
        }

        if (checkSyscalls()) {
            tvSyscallStatus.setText("ACTIVE");
            tvSyscallStatus.setTextColor(getColor(R.color.cyan));
        } else {
            tvSyscallStatus.setText("INACTIVE");
            tvSyscallStatus.setTextColor(getColor(android.R.color.holo_red_light));
        }
    }

    private boolean isDeviceRooted() {
        String[] paths = { "/system/app/Superuser.apk", "/sbin/su", "/system/bin/su", "/system/xbin/su", "/data/local/xbin/su", "/data/local/bin/su", "/system/sd/xbin/su", "/system/bin/failsafe/su", "/data/local/su", "/su/bin/su"};
        for (String path : paths) {
            if (new File(path).exists()) return true;
        }
        return Build.TAGS != null && Build.TAGS.contains("test-keys");
    }

    private boolean checkSyscalls() {
        try {
            Process process = Runtime.getRuntime().exec("cat /proc/kallsyms | grep sys_call_table");
            return process.waitFor() == 0;
        } catch (Exception e) {
            return false;
        }
    }
}