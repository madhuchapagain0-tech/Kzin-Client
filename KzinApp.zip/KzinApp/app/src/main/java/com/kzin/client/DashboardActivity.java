package com.kzin.client;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Debug;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Locale;

public class DashboardActivity extends Activity {

    LinearLayout pageGames, pageProfile, pageSettings;
    TextView navGames, navProfile, navSettings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 🛡️ APP PROTECTION: Anti-Debug (Blocks people from inspecting your app)
        if (Debug.isDebuggerConnected() || Debug.waitingForDebugger()) {
            finishAffinity();
            System.exit(0);
        }

        // 🛡️ APP PROTECTION: Block screenshots on the dashboard
        getWindow().setFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE, android.view.WindowManager.LayoutParams.FLAG_SECURE);

        setContentView(R.layout.activity_main);

        pageGames = findViewById(R.id.pageGames);
        pageProfile = findViewById(R.id.pageProfile);
        pageSettings = findViewById(R.id.pageSettings);
        navGames = findViewById(R.id.navGames);
        navProfile = findViewById(R.id.navProfile);
        navSettings = findViewById(R.id.navSettings);

        navGames.setOnClickListener(v -> switchTab(0));
        navProfile.setOnClickListener(v -> switchTab(1));
        navSettings.setOnClickListener(v -> switchTab(2));

        loadProfileData();

        // Launch FF MAX Button
        findViewById(R.id.btnLaunchFF).setOnClickListener(v -> {
            Toast.makeText(this, "Launching FF MAX & Injecting...", Toast.LENGTH_SHORT).show();
            injectFreeFire();
        });
    }

    private void switchTab(int tabIndex) {
        pageGames.setVisibility(tabIndex == 0 ? View.VISIBLE : View.GONE);
        pageProfile.setVisibility(tabIndex == 1 ? View.VISIBLE : View.GONE);
        pageSettings.setVisibility(tabIndex == 2 ? View.VISIBLE : View.GONE);

        if (tabIndex == 0) pageGames.startAnimation(AnimationUtils.loadAnimation(this, R.anim.slide_up));
        if (tabIndex == 1) pageProfile.startAnimation(AnimationUtils.loadAnimation(this, R.anim.slide_up));
        if (tabIndex == 2) pageSettings.startAnimation(AnimationUtils.loadAnimation(this, R.anim.slide_up));

        navGames.setTextColor(getColor(tabIndex == 0 ? R.color.cyan : R.color.text_grey));
        navProfile.setTextColor(getColor(tabIndex == 1 ? R.color.cyan : R.color.text_grey));
        navSettings.setTextColor(getColor(tabIndex == 2 ? R.color.cyan : R.color.text_grey));
    }

    private void loadProfileData() {
        Intent intent = getIntent();
        String userKey = intent.getStringExtra("USER_KEY");
        String expiry = intent.getStringExtra("EXPIRY");
        String hwid = intent.getStringExtra("HWID");

        if (userKey == null) userKey = "KZIN-UNKNOWN";
        if (expiry == null) expiry = "Lifetime";
        if (hwid == null) hwid = android.provider.Settings.Secure.getString(getContentResolver(), android.provider.Settings.Secure.ANDROID_ID);

        TextView tvUserKey = findViewById(R.id.tvUserKey);
        TextView tvExpiry = findViewById(R.id.tvExpiry);
        TextView tvHwid = findViewById(R.id.tvHwid);
        
        tvUserKey.setText(userKey);
        tvExpiry.setText(expiry);
        tvHwid.setText(hwid);

        String finalHwid = hwid;
        ImageView btnCopyHwid = findViewById(R.id.btnCopyHwid);
        btnCopyHwid.setOnClickListener(v -> {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData clip = ClipData.newPlainText("HWID", finalHwid);
            clipboard.setPrimaryClip(clip);
            Toast.makeText(this, "HWID Copied!", Toast.LENGTH_SHORT).show();
        });

        // Load Device Specs
        TextView tvAndroid = findViewById(R.id.tvAndroid);
        TextView tvModel = findViewById(R.id.tvModel);
        TextView tvBrand = findViewById(R.id.tvBrand);
        TextView tvAbi = findViewById(R.id.tvAbi);
        TextView tvKernel = findViewById(R.id.tvKernel);
        TextView tvDisplay = findViewById(R.id.tvDisplay);

        tvAndroid.setText("Android " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")");
        tvModel.setText(Build.MODEL);
        tvBrand.setText(Build.BRAND);
        tvAbi.setText(Build.SUPPORTED_ABIS[0]);
        tvKernel.setText(System.getProperty("os.version"));

        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        float refreshRate = getWindowManager().getDefaultDisplay().getRefreshRate();
        tvDisplay.setText(String.format(Locale.US, "%.0fhz, %dx%d", refreshRate, metrics.widthPixels, metrics.heightPixels));
    }

    private void injectFreeFire() {
        new Thread(() -> {
            try {
                // 🛡️ APP PROTECTION: Frida / Xposed Detection
                if (isHooked()) {
                    runOnUiThread(() -> Toast.makeText(this, "Security Violation: Hook Detected!", Toast.LENGTH_LONG).show());
                    return;
                }

                String tempPath = "/data/local/tmp/kzin_ff";
                File injectorDir = new File(tempPath);
                if (!injectorDir.exists()) injectorDir.mkdirs();

                File injectorFile = new File(injectorDir, "injector");
                File libFile = new File(injectorDir, "libKzin.so"); // Make sure this matches your CMakeLists.txt output

                // Extract Injector
                InputStream is = getAssets().open("injector");
                FileOutputStream os = new FileOutputStream(injectorFile);
                byte[] buffer = new byte[1024];
                int length;
                while ((length = is.read(buffer)) > 0) os.write(buffer, 0, length);
                os.close(); is.close();

                // Extract libKzin.so
                is = getAssets().open("libKzin.so");
                os = new FileOutputStream(libFile);
                while ((length = is.read(buffer)) > 0) os.write(buffer, 0, length);
                os.close(); is.close();

                // 🚨 IMPROVEMENT: Write Expiry Date for the Mod Menu to read
                String userExpiry = getIntent().getStringExtra("EXPIRY");
                if (userExpiry == null || userExpiry.isEmpty()) userExpiry = "Lifetime";
                
                String writeExpiryCmd = "echo '" + userExpiry + "' > /data/local/tmp/kzin_expiry.txt";

                // Launch Game -> Write Expiry -> Wait 25s -> Inject -> CLEANUP
                String command = "su -c \"" +
                        writeExpiryCmd + " && " +
                        "monkey -p com.dts.freefiremax -c android.intent.category.LAUNCHER 1 && " +
                        "sleep 25 && " +
                        "chmod 777 " + injectorFile.getAbsolutePath() + " && " +
                        "chmod 777 " + libFile.getAbsolutePath() + " && " +
                        injectorFile.getAbsolutePath() + " com.dts.freefiremax " + libFile.getAbsolutePath() + " && " +
                        "sleep 5 && rm -rf " + tempPath + "\""; // Deletes the files after injection!

                Process process = Runtime.getRuntime().exec(command);
                process.waitFor();

                runOnUiThread(() -> {
                    Toast.makeText(this, "Injected Safely! Open FF MAX.", Toast.LENGTH_SHORT).show();
                    switchTab(2); // Auto-switch to Settings tab
                });

            } catch (Exception e) {
                runOnUiThread(() -> {
                    Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }

    // 🛡️ Helper function to detect Frida/Magisk hooks
    private boolean isHooked() {
        try {
            throw new Exception("Check Stack Trace");
        } catch (Exception e) {
            for (StackTraceElement element : e.getStackTrace()) {
                if (element.getClassName().contains("frida") || element.getClassName().contains("xposed")) {
                    return true;
                }
            }
        }
        return false;
    }
}