package com.kzin.client;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

public class DashboardActivity extends Activity {

    LinearLayout pageGames, pageProfile, pageSettings;
    TextView navGames, navProfile, navSettings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        pageGames = findViewById(R.id.pageGames);
        pageProfile = findViewById(R.id.pageProfile);
        pageSettings = findViewById(R.id.pageSettings);
        
        navGames = findViewById(R.id.navGames);
        navProfile = findViewById(R.id.navProfile);
        navSettings = findViewById(R.id.navSettings);

        navGames.setOnClickListener(v -> switchTab(0));
        navProfile.setOnClickListener(v -> switchTab(1));
        navSettings.setOnClickListener(v -> switchTab(2));

        String userKey = getIntent().getStringExtra("USER_KEY");
        String hwid = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        String abi = Build.SUPPORTED_ABIS[0];

        ((TextView) findViewById(R.id.tvUserKey)).setText("User: " + userKey);
        ((TextView) findViewById(R.id.tvHwid)).setText("HWID: " + hwid);
        ((TextView) findViewById(R.id.tvAndroid)).setText("Android: " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")");
        ((TextView) findViewById(R.id.tvModel)).setText("Model: " + Build.MODEL);
        ((TextView) findViewById(R.id.tvBrand)).setText("Brand: " + Build.BRAND);
        ((TextView) findViewById(R.id.tvAbi)).setText("ABI: " + abi);
    }

    private void switchTab(int tabIndex) {
        pageGames.setVisibility(View.GONE);
        pageProfile.setVisibility(View.GONE);
        pageSettings.setVisibility(View.GONE);

        navGames.setTextColor(0xFF888888);
        navProfile.setTextColor(0xFF888888);
        navSettings.setTextColor(0xFF888888);

        if (tabIndex == 0) {
            pageGames.setVisibility(View.VISIBLE);
            navGames.setTextColor(0xFF00E5FF);
        } else if (tabIndex == 1) {
            pageProfile.setVisibility(View.VISIBLE);
            navProfile.setTextColor(0xFF00E5FF);
        } else {
            pageSettings.setVisibility(View.VISIBLE);
            navSettings.setTextColor(0xFF00E5FF);
        }
    }
}