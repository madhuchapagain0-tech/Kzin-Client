package com.kzin.client;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Debug;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Locale;

public class DashboardActivity extends Activity {

    LinearLayout pageGames, pageProfile, pageSettings;
    TextView navGames, navProfile, navSettings;
    TextView tvRootStatus, tvSyscallStatus;
    private Handler handler = new Handler(Looper.getMainLooper());
    private Runnable statusUpdater;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 🛡️ Anti-Debug Protection
        if (Debug.isDebuggerConnected() || Debug.waitingForDebugger()) {
            finishAffinity();
            System.exit(0);
        }

        getWindow().setFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE, android.view.WindowManager.LayoutParams.FLAG_SECURE);
        setContentView(R.layout.activity_main);

        pageGames = findViewById(R.id.pageGames);
        pageProfile = findViewById(R.id.pageProfile);
        pageSettings = findViewById(R.id.pageSettings);
        navGames = findViewById(R.id.navGames);
        navProfile = findViewById(R.id.navProfile);
        navSettings = findViewById(R.id.navSettings);
        
        tvRootStatus = findViewById(R.id.tvRootStatus);
        tvSyscallStatus = findViewById(R.id.tvSyscallStatus);

        navGames.setOnClickListener(v -> switchTab(0));
        navProfile.setOnClickListener(v -> switchTab(1));
        navSettings.setOnClickListener(v -> switchTab(2));

        loadProfileData();

        // Auto-refresh status in Settings tab
        statusUpdater = new Runnable() {
            @Override
            public void run() {
                updateStatuses();
                handler.postDelayed(this, 2000);
            }
        };

        findViewById(R.id.btnLaunchFF).setOnClickListener(v -> injectFreeFire());
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(statusUpdater);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(statusUpdater);
    }

    private void switchTab(int tabIndex) {
        pageGames.setVisibility(tabIndex == 0 ? View.VISIBLE : View.GONE);
        pageProfile.setVisibility(tabIndex == 1 ? View.VISIBLE : View.GONE);
        pageSettings.setVisibility(tabIndex == 2 ? View.VISIBLE : View.GONE);

        if (tabIndex == 0) pageGames.startAnimation(AnimationUtils.loadAnimation(this, R.anim.slide_up));
        if (tabIndex == 1) pageProfile.startAnimation(AnimationUtils.loadAnimation(this, R.anim.slide_up));
        if (tabIndex == 2) pageSettings.startAnimation(AnimationUtils.loadAnimation(this, R.anim.slide_up));

        navGames.setTextColor(getColor(tabIndex == 0 ? R.color.cyan : R.color.text_grey));
        navProfile.setTextColor(getColor(tabIndex == 1 ? R.color.cyan : R.color.text_grey));
        navSettings.setTextColor(getColor(tabIndex == 2 ? R.color.cyan : R.color.text_grey));
    }

    private void updateStatuses() {
        new Thread(() -> {
            boolean hasRoot = false;
            try {
                Process p = Runtime.getRuntime().exec("su -c id");
                hasRoot = p.waitFor() == 0;
            } catch (Exception ignored) {}

            final boolean finalHasRoot = hasRoot;

            runOnUiThread(() -> {
                if (finalHasRoot) {
                    tvRootStatus.setText("DETECTED");
                    tvRootStatus.setTextColor(Color.parseColor("#00FF66"));
                    tvRootStatus.setBackgroundResource(R.drawable.badge_active);
                } else {
                    tvRootStatus.setText("NOT ROOTED");
                    tvRootStatus.setTextColor(Color.parseColor("#FF003C"));
                    tvRootStatus.setBackgroundResource(R.drawable.badge_inactive);
                }
            });
        }).start();
    }

    private void loadProfileData() {
        Intent intent = getIntent();
        String userKey = intent.getStringExtra("USER_KEY");
        String expiry = intent.getStringExtra("EXPIRY");
        String hwid = intent.getStringExtra("HWID");

        if (userKey == null) userKey = "KZIN-UNKNOWN";
        if (expiry == null) expiry = "Lifetime";
        if (hwid == null) hwid = android.provider.Settings.Secure.getString(getContentResolver(), android.provider.Settings.Secure.ANDROID_ID);

        TextView tvUserKey = findViewById(R.id.tvUserKey);
        TextView tvExpiry = findViewById(R.id.tvExpiry);
        TextView tvHwid = findViewById(R.id.tvHwid);
        
        tvUserKey.setText(userKey);
        tvExpiry.setText(expiry);
        tvHwid.setText(hwid);

        String finalHwid = hwid;
        findViewById(R.id.btnCopyHwid).setOnClickListener(v -> {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData clip = ClipData.newPlainText("HWID", finalHwid);
            clipboard.setPrimaryClip(clip);
            Toast.makeText(this, "HWID Copied to Clipboard!", Toast.LENGTH_SHORT).show();
        });

        TextView tvAndroid = findViewById(R.id.tvAndroid);
        TextView tvModel = findViewById(R.id.tvModel);
        TextView tvBrand = findViewById(R.id.tvBrand);
        TextView tvAbi = findViewById(R.id.tvAbi);
        TextView tvKernel = findViewById(R.id.tvKernel);
        TextView tvDisplay = findViewById(R.id.tvDisplay);

        tvAndroid.setText("Android " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")");
        tvModel.setText(Build.MODEL);
        tvBrand.setText(Build.BRAND);
        tvAbi.setText(Build.SUPPORTED_ABIS[0]);
        tvKernel.setText(System.getProperty("os.version"));

        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        float refreshRate = getWindowManager().getDefaultDisplay().getRefreshRate();
        tvDisplay.setText(String.format(Locale.US, "%.0fhz, %dx%d", refreshRate, metrics.widthPixels, metrics.heightPixels));
    }

    private void injectFreeFire() {
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Preparing Stealth Injection...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        new Thread(() -> {
            try {
                Process rootCheck = Runtime.getRuntime().exec("su -c id");
                if (rootCheck.waitFor() != 0) {
                    runOnUiThread(() -> {
                        progressDialog.dismiss();
                        Toast.makeText(this, "Root Access Denied! Please grant root.", Toast.LENGTH_LONG).show();
                    });
                    return;
                }

                String tempPath = "/data/local/tmp/kzin_ff";
                File injectorDir = new File(tempPath);
                if (!injectorDir.exists()) injectorDir.mkdirs();

                File injectorFile = new File(injectorDir, "injector");
                File libFile = new File(injectorDir, "libKzin.so");

                InputStream is = getAssets().open("injector");
                FileOutputStream os = new FileOutputStream(injectorFile);
                byte[] buffer = new byte[1024];
                int length;
                while ((length = is.read(buffer)) > 0) os.write(buffer, 0, length);
                os.close(); is.close();

                is = getAssets().open("libKzin.so");
                os = new FileOutputStream(libFile);
                while ((length = is.read(buffer)) > 0) os.write(buffer, 0, length);
                os.close(); is.close();

                String userExpiry = getIntent().getStringExtra("EXPIRY");
                if (userExpiry == null || userExpiry.isEmpty()) userExpiry = "Lifetime";
                
                // Write expiry to file for C++ menu
                String writeExpiryCmd = "echo '" + userExpiry + "' > /data/local/tmp/kzin_expiry.txt";

                // Execute AndKittyInjector
                String command = "su -c \"" +
                        writeExpiryCmd + " && " +
                        "monkey -p com.dts.freefiremax -c android.intent.category.LAUNCHER 1 && " +
                        "sleep 25 && " +
                        "chmod 777 " + injectorFile.getAbsolutePath() + " && " +
                        "chmod 777 " + libFile.getAbsolutePath() + " && " +
                        injectorFile.getAbsolutePath() + " --memfd --hide com.dts.freefiremax " + libFile.getAbsolutePath() + " && " +
                        "sleep 5 && rm -rf " + tempPath + "\"";

                Process process = Runtime.getRuntime().exec(command);
                process.waitFor();

                runOnUiThread(() -> {
                    progressDialog.dismiss();
                    Toast.makeText(this, "Injected Successfully!", Toast.LENGTH_SHORT).show();
                    tvSyscallStatus.setText("INJECTED");
                    tvSyscallStatus.setTextColor(Color.parseColor("#00F0FF"));
                    tvSyscallStatus.setBackgroundResource(R.drawable.badge_active);
                    switchTab(2); 
                });

            } catch (Exception e) {
                runOnUiThread(() -> {
                    progressDialog.dismiss();
                    Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }
}