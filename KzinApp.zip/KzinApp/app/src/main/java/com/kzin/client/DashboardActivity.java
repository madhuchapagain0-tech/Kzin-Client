package com.kzin.client;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.AssetManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.Locale;

public class DashboardActivity extends Activity {

    LinearLayout pageGames, pageProfile, pageSettings;
    TextView navGames, navProfile, navSettings;
    TextView tvRootStatus, tvSyscallStatus;

    private Handler handler = new Handler(Looper.getMainLooper());
    private Runnable statusUpdater;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        pageGames = findViewById(R.id.pageGames);
        pageProfile = findViewById(R.id.pageProfile);
        pageSettings = findViewById(R.id.pageSettings);
        navGames = findViewById(R.id.navGames);
        navProfile = findViewById(R.id.navProfile);
        navSettings = findViewById(R.id.navSettings);
        
        tvRootStatus = findViewById(R.id.tvRootStatus);
        tvSyscallStatus = findViewById(R.id.tvSyscallStatus);

        navGames.setOnClickListener(v -> switchTab(0));
        navProfile.setOnClickListener(v -> switchTab(1));
        navSettings.setOnClickListener(v -> switchTab(2));

        loadProfileData();

        // Auto-refresh status every 2 seconds
        statusUpdater = new Runnable() {
            @Override
            public void run() {
                loadSettingsData();
                handler.postDelayed(this, 2000);
            }
        };

        findViewById(R.id.btnLaunchMLBB).setOnClickListener(v -> {
            Toast.makeText(this, "Extracting & Injecting...", Toast.LENGTH_SHORT).show();
            executeMLBBScript();
        });
        
        findViewById(R.id.btnViewLog).setOnClickListener(v -> showTerminalLog());
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(statusUpdater);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(statusUpdater);
    }

    private void switchTab(int tabIndex) {
        pageGames.setVisibility(tabIndex == 0 ? View.VISIBLE : View.GONE);
        pageProfile.setVisibility(tabIndex == 1 ? View.VISIBLE : View.GONE);
        pageSettings.setVisibility(tabIndex == 2 ? View.VISIBLE : View.GONE);

        navGames.setTextColor(getColor(tabIndex == 0 ? R.color.cyan : R.color.text_grey));
        navProfile.setTextColor(getColor(tabIndex == 1 ? R.color.cyan : R.color.text_grey));
        navSettings.setTextColor(getColor(tabIndex == 2 ? R.color.cyan : R.color.text_grey));
    }

    private void loadProfileData() {
        Intent intent = getIntent();
        String userKey = intent.getStringExtra("USER_KEY");
        String expiry = intent.getStringExtra("EXPIRY");
        String hwid = intent.getStringExtra("HWID");

        if (userKey == null) userKey = "KZIN-UNKNOWN";
        if (expiry == null) expiry = "Lifetime";
        if (hwid == null) hwid = android.provider.Settings.Secure.getString(getContentResolver(), android.provider.Settings.Secure.ANDROID_ID);

        TextView tvUserKey = findViewById(R.id.tvUserKey);
        TextView tvExpiry = findViewById(R.id.tvExpiry);
        TextView tvHwid = findViewById(R.id.tvHwid);
        
        tvUserKey.setText(userKey);
        tvExpiry.setText(expiry);
        tvHwid.setText(hwid);

        String finalHwid = hwid;
        ImageView btnCopyHwid = findViewById(R.id.btnCopyHwid);
        btnCopyHwid.setOnClickListener(v -> {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData clip = ClipData.newPlainText("HWID", finalHwid);
            clipboard.setPrimaryClip(clip);
            Toast.makeText(this, "HWID Copied!", Toast.LENGTH_SHORT).show();
        });

        TextView tvAndroid = findViewById(R.id.tvAndroid);
        TextView tvModel = findViewById(R.id.tvModel);
        TextView tvBrand = findViewById(R.id.tvBrand);
        TextView tvAbi = findViewById(R.id.tvAbi);
        TextView tvKernel = findViewById(R.id.tvKernel);
        TextView tvDisplay = findViewById(R.id.tvDisplay);

        tvAndroid.setText("Android " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")");
        tvModel.setText(Build.MODEL);
        tvBrand.setText(Build.BRAND);
        tvAbi.setText(Build.SUPPORTED_ABIS[0]);
        tvKernel.setText(System.getProperty("os.version"));

        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        float refreshRate = getWindowManager().getDefaultDisplay().getRefreshRate();
        tvDisplay.setText(String.format(Locale.US, "%.0fhz, %dx%d", refreshRate, metrics.widthPixels, metrics.heightPixels));
    }

    private void loadSettingsData() {
        if (isDeviceRooted()) {
            tvRootStatus.setText("DETECTED");
            tvRootStatus.setTextColor(getColor(R.color.success));
            tvRootStatus.setBackgroundResource(R.drawable.badge_active);
        } else {
            tvRootStatus.setText("NOT ROOTED");
            tvRootStatus.setTextColor(getColor(R.color.danger));
            tvRootStatus.setBackgroundResource(R.drawable.badge_inactive);
        }

        if (checkSyscalls()) {
            tvSyscallStatus.setText("ACTIVE");
            tvSyscallStatus.setTextColor(getColor(R.color.success));
            tvSyscallStatus.setBackgroundResource(R.drawable.badge_active);
        } else {
            tvSyscallStatus.setText("INACTIVE");
            tvSyscallStatus.setTextColor(getColor(R.color.danger));
            tvSyscallStatus.setBackgroundResource(R.drawable.badge_inactive);
        }
    }

    private boolean isDeviceRooted() {
        try {
            Process process = Runtime.getRuntime().exec("su -c id");
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line = reader.readLine();
            return line != null && line.contains("uid=0");
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkSyscalls() {
        try {
            // Check specific driver hooks
            if (new File("/dev/rt-dev").exists() || new File("/proc/rt-dev").exists()) return true;
            if (new File("/dev/rtproc").exists() || new File("/proc/rtproc").exists()) return true;
            
            // Check process list for starcool/meliora/rt-dev
            Process process = Runtime.getRuntime().exec("su -c ps -A");
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                String lower = line.toLowerCase();
                if (lower.contains("rt-dev") || lower.contains("rt_proc") || lower.contains("meliora") || lower.contains("starcool")) {
                    return true;
                }
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    private void executeMLBBScript() {
        new Thread(() -> {
            try {
                File dir = new File("/data/local/tmp/kzin_mlbb");
                if (!dir.exists()) dir.mkdirs();

                // 1. Extract ALL files from assets (all 24 .sh files)
                AssetManager am = getAssets();
                String[] files = am.list("");
                if (files != null) {
                    for (String filename : files) {
                        File outFile = new File(dir, filename);
                        InputStream is = am.open(filename);
                        OutputStream os = new FileOutputStream(outFile);
                        byte[] buffer = new byte[1024];
                        int length;
                        while ((length = is.read(buffer)) > 0) {
                            os.write(buffer, 0, length);
                        }
                        os.flush();
                        os.close();
                        is.close();
                    }
                }

                File logFile = new File(dir, "debug.log");
                if (logFile.exists()) logFile.delete();

                // 2. Bulletproof Execution (Prevents Kernel Panic / Reboot)
                // su -mm: Magisk Mount Namespace
                // setsid: Detaches process entirely from app lifecycle
                // printf: Injects '3' and '2' automatically
                String command = "su -mm -c \"cd " + dir.getAbsolutePath() + 
                                 " && chmod -R 777 * " +
                                 " && export PATH=$PATH:/system/bin:/system/xbin:/sbin " +
                                 " && export TERM=xterm-256color " +
                                 " && printf '3\\n2\\n' | setsid sh mlbb.sh > debug.log 2>&1 &\"";

                ProcessBuilder pb = new ProcessBuilder("su", "-c", command);
                pb.redirectErrorStream(true);
                pb.start();

                runOnUiThread(() -> {
                    Toast.makeText(this, "Injected! Check Terminal Log.", Toast.LENGTH_LONG).show();
                    switchTab(2); 
                });

            } catch (Exception e) {
                runOnUiThread(() -> {
                    Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }
    
    private void showTerminalLog() {
        File logFile = new File("/data/local/tmp/kzin_mlbb/debug.log");
        if (!logFile.exists()) {
            Toast.makeText(this, "No log found. Launch the script first.", Toast.LENGTH_SHORT).show();
            return;
        }
        
        try {
            Process p = Runtime.getRuntime().exec("su -c cat " + logFile.getAbsolutePath());
            BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append("\n");
            }
            reader.close();
            
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Terminal Output");
            builder.setMessage(sb.toString());
            builder.setPositiveButton("CLOSE", null);
            builder.show();
            
        } catch (Exception e) {
            Toast.makeText(this, "Failed to read log.", Toast.LENGTH_SHORT).show();
        }
    }
}