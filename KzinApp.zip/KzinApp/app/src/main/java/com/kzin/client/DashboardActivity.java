package com.kzin.client;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;

public class DashboardActivity extends Activity {

    LinearLayout pageGames, pageProfile, pageSettings;
    TextView navGames, navProfile, navSettings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Navigation Setup
        pageGames = findViewById(R.id.pageGames);
        pageProfile = findViewById(R.id.pageProfile);
        pageSettings = findViewById(R.id.pageSettings);
        navGames = findViewById(R.id.navGames);
        navProfile = findViewById(R.id.navProfile);
        navSettings = findViewById(R.id.navSettings);

        navGames.setOnClickListener(v -> switchTab(0));
        navProfile.setOnClickListener(v -> switchTab(1));
        navSettings.setOnClickListener(v -> switchTab(2));

        // Profile Setup
        String userKey = getIntent().getStringExtra("USER_KEY");
        String hwid = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        String abi = Build.SUPPORTED_ABIS[0];

        ((TextView) findViewById(R.id.tvUserKey)).setText("License: " + userKey);
        ((TextView) findViewById(R.id.tvHwid)).setText("HWID: " + hwid);
        ((TextView) findViewById(R.id.tvAndroid)).setText("Android: " + Build.VERSION.RELEASE);
        ((TextView) findViewById(R.id.tvModel)).setText("Device: " + Build.MODEL);
        ((TextView) findViewById(R.id.tvAbi)).setText("Architecture: " + abi);

        // Launch Buttons
        Button btnFF = findViewById(R.id.btnLaunchFF);
        Button btnMLBB = findViewById(R.id.btnLaunchMLBB);

        btnFF.setOnClickListener(v -> {
            Toast.makeText(DashboardActivity.this, "Loading Free Fire Native Module...", Toast.LENGTH_SHORT).show();
        });

        btnMLBB.setOnClickListener(v -> {
            Toast.makeText(DashboardActivity.this, "Starting MLBB Injector... Grant Root!", Toast.LENGTH_SHORT).show();
            runMLBBScript();
        });
    }

    private void switchTab(int tabIndex) {
        pageGames.setVisibility(View.GONE);
        pageProfile.setVisibility(View.GONE);
        pageSettings.setVisibility(View.GONE);
        navGames.setTextColor(0xFF888888);
        navProfile.setTextColor(0xFF888888);
        navSettings.setTextColor(0xFF888888);

        if (tabIndex == 0) {
            pageGames.setVisibility(View.VISIBLE);
            navGames.setTextColor(0xFF00E5FF);
        } else if (tabIndex == 1) {
            pageProfile.setVisibility(View.VISIBLE);
            navProfile.setTextColor(0xFF00E5FF);
        } else {
            pageSettings.setVisibility(View.VISIBLE);
            navSettings.setTextColor(0xFF00E5FF);
        }
    }

    // MLBB AUTO-INJECTOR
    private void runMLBBScript() {
        try {
            InputStream is = getAssets().open("mlbb.sh");
            File scriptFile = new File(getFilesDir(), "mlbb.sh");
            FileOutputStream fos = new FileOutputStream(scriptFile);
            byte[] buffer = new byte[1024];
            int length;
            while ((length = is.read(buffer)) > 0) {
                fos.write(buffer, 0, length);
            }
            fos.flush();
            fos.close();
            is.close();

            Runtime.getRuntime().exec("chmod 755 " + scriptFile.getAbsolutePath());

            Process process = Runtime.getRuntime().exec("su");
            final OutputStream stdin = process.getOutputStream();
            final InputStream stdout = process.getInputStream();
            final DataOutputStream writer = new DataOutputStream(stdin);
            final BufferedReader reader = new BufferedReader(new InputStreamReader(stdout));

            new Thread(() -> {
                try {
                    writer.writeBytes("sh " + scriptFile.getAbsolutePath() + "\n");
                    writer.flush();

                    String line;
                    boolean keySent = false, rootSent = false, driverSent = false;

                    while ((line = reader.readLine()) != null) {
                        if (line.contains("Masukkan License Key") && !keySent) {
                            Thread.sleep(500);
                            writer.writeBytes("FREE-LIFETIME\n");
                            writer.flush();
                            keySent = true;
                        }
                        if (line.contains("Input:") && keySent && !rootSent) {
                            Thread.sleep(500);
                            writer.writeBytes("1\n");
                            writer.flush();
                            rootSent = true;
                        }
                        if (line.contains("Select Driver >") && rootSent && !driverSent) {
                            Thread.sleep(500);
                            writer.writeBytes("3\n");
                            writer.flush();
                            driverSent = true;
                            runOnUiThread(() -> Toast.makeText(DashboardActivity.this, "MLBB Cheat Injected Successfully!", Toast.LENGTH_LONG).show());
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }).start();

        } catch (Exception e) {
            Toast.makeText(this, "Error: Root required for MLBB!", Toast.LENGTH_LONG).show();
        }
    }
}