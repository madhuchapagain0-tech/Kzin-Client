package com.kzin.client;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.TextView;

public class DashboardActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String userKey = getIntent().getStringExtra("USER_KEY");
        String hwid = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);

        TextView tvUserKey = (TextView) findViewById(R.id.tvUserKey);
        TextView tvHwid = (TextView) findViewById(R.id.tvHwid);
        TextView tvAndroid = (TextView) findViewById(R.id.tvAndroid);
        TextView tvModel = (TextView) findViewById(R.id.tvModel);
        TextView tvBrand = (TextView) findViewById(R.id.tvBrand);

        tvUserKey.setText("User: " + userKey);
        tvHwid.setText("HWID: " + hwid);
        tvAndroid.setText("Android: " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")");
        tvModel.setText("Model: " + Build.MODEL);
        tvBrand.setText("Brand: " + Build.BRAND);
    }
}